University Portal Demo
======================

This is a demo university portal built with Flask + SQLite. It includes:
- Student and Faculty login
- Student dashboard: timetable, enrolled courses, attendance summary, grades, profile
- Faculty dashboard: assigned courses, attendance marking, grading, timetable, profile
- Simple seeded demo data (10 students, 2 faculties, 3 courses)
- Demo credentials listed below.

How to run (locally)
--------------------
1. Create virtual environment and activate:
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # macOS / Linux:
   source venv/bin/activate

2. Install requirements:
   pip install -r requirements.txt

3. Run the app:
   python app.py

4. Open http://127.0.0.1:5000 in your browser.

Demo credentials
----------------
Faculties:
 - username: faculty1  | password: fac1pass
 - username: faculty2  | password: fac2pass

Students:
 - username: student1  | password: stud1pass
 - username: student2  | password: stud2pass
 ...
 - username: student10 | password: stud10pass

Notes
-----
- This project is for demonstration and learning. For production, use stronger secret keys, structured blueprints, CSRF protection, better frontend, and proper authentication.
- Faculty actions (attendance/grades) update data that is immediately visible in student dashboards.
