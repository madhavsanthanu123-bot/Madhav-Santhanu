from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import date, time

app = Flask(__name__)
app.config['SECRET_KEY'] = 'change_this_secret_key_for_production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///university.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# --- Models ---
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'student' or 'faculty'
    full_name = db.Column(db.String(120))
    email = db.Column(db.String(120))
    # student-specific
    hostel = db.Column(db.String(120))
    roll_no = db.Column(db.String(50))

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    title = db.Column(db.String(200), nullable=False)
    faculty_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    faculty = db.relationship('User', backref='courses')

class Enrollment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    student = db.relationship('User', backref='enrollments')
    course = db.relationship('Course', backref='enrollments')

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    date = db.Column(db.Date, nullable=False)
    present = db.Column(db.Boolean, default=False)
    course = db.relationship('Course', backref='attendances')
    student = db.relationship('User', backref='attendances')

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    marks = db.Column(db.Float)
    letter = db.Column(db.String(4))
    course = db.relationship('Course', backref='grades')
    student = db.relationship('User', backref='grades')

class Timetable(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'))
    day = db.Column(db.String(20))  # e.g., Monday
    start_time = db.Column(db.String(10))
    end_time = db.Column(db.String(10))
    location = db.Column(db.String(100))
    course = db.relationship('Course', backref='timetable')

# --- Utility functions ---
def seed_data():
    if User.query.first():
        return

    # Create faculties
    f1 = User(username='faculty1', password_hash=generate_password_hash('fac1pass'), role='faculty', full_name='Dr. Anita Rao', email='anita@uni.edu')
    f2 = User(username='faculty2', password_hash=generate_password_hash('fac2pass'), role='faculty', full_name='Prof. Vikram Singh', email='vikram@uni.edu')
    db.session.add_all([f1, f2])
    db.session.commit()

    # Create students
    students = []
    for i in range(1, 11):
        s = User(
            username=f'student{i}',
            password_hash=generate_password_hash(f'stud{i}pass'),
            role='student',
            full_name=f'Student {i}',
            email=f'student{i}@uni.edu',
            hostel=f'Hostel-{(i%3)+1}',
            roll_no=f'2025CS{100+i}'
        )
        students.append(s)
    db.session.add_all(students)
    db.session.commit()

    # Create courses
    c1 = Course(code='CS101', title='Introduction to Computer Science', faculty_id=f1.id)
    c2 = Course(code='CS102', title='Data Structures', faculty_id=f2.id)
    c3 = Course(code='CS103', title='Database Systems', faculty_id=f1.id)
    db.session.add_all([c1, c2, c3])
    db.session.commit()

    # Enroll students (first 7 in c1, all in c2 etc.)
    for idx, s in enumerate(students):
        e1 = Enrollment(student_id=s.id, course_id=c1.id)
        if idx < 8:
            db.session.add(e1)
        e2 = Enrollment(student_id=s.id, course_id=c2.id)
        db.session.add(e2)
        if idx % 2 == 0:
            e3 = Enrollment(student_id=s.id, course_id=c3.id)
            db.session.add(e3)
    db.session.commit()

    # Timetable entries
    tt = [
        Timetable(course_id=c1.id, day='Monday', start_time='09:00', end_time='10:30', location='Room A1'),
        Timetable(course_id=c2.id, day='Tuesday', start_time='11:00', end_time='12:30', location='Room B2'),
        Timetable(course_id=c3.id, day='Wednesday', start_time='14:00', end_time='15:30', location='Lab 3'),
    ]
    db.session.add_all(tt)
    db.session.commit()

    # Attendance for last 3 days for enrolled students (random-ish pattern)
    from datetime import timedelta
    base = date.today()
    for d in range(3):
        thedate = base - timedelta(days=d)
        for en in Enrollment.query.all():
            a = Attendance(course_id=en.course_id, student_id=en.student_id, date=thedate, present=( (en.student_id + d + en.course_id) % 2 == 0))
            db.session.add(a)
    db.session.commit()

    # Grades (some sample)
    for en in Enrollment.query.limit(30).all():
        g = Grade(course_id=en.course_id, student_id=en.student_id, marks=60 + (en.student_id % 40))
        # simple mapping to letter
        if g.marks >= 85:
            g.letter = 'A'
        elif g.marks >= 70:
            g.letter = 'B'
        elif g.marks >= 55:
            g.letter = 'C'
        else:
            g.letter = 'D'
        db.session.add(g)
    db.session.commit()

# --- Routes ---
@app.before_first_request
def setup():
    db.create_all()
    seed_data()

@app.route('/')
def index():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user.role == 'student':
            return redirect(url_for('student_dashboard'))
        else:
            return redirect(url_for('faculty_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            flash('Logged in successfully.', 'success')
            if user.role == 'student':
                return redirect(url_for('student_dashboard'))
            else:
                return redirect(url_for('faculty_dashboard'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out', 'info')
    return redirect(url_for('login'))

# --- Student views ---
@app.route('/student/dashboard')
def student_dashboard():
    user = User.query.get(session.get('user_id'))
    if not user or user.role != 'student':
        return redirect(url_for('login'))
    enrollments = Enrollment.query.filter_by(student_id=user.id).all()
    courses = [e.course for e in enrollments]
    # attendance summary
    attendance_info = []
    for c in courses:
        total = Attendance.query.filter_by(course_id=c.id, student_id=user.id).count()
        present = Attendance.query.filter_by(course_id=c.id, student_id=user.id, present=True).count()
        attendance_info.append({'course': c, 'total': total, 'present': present})
    # grades
    grades = Grade.query.filter_by(student_id=user.id).all()
    return render_template('student_dashboard.html', user=user, courses=courses, attendance_info=attendance_info, grades=grades)

@app.route('/student/profile')
def student_profile():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='student':
        return redirect(url_for('login'))
    return render_template('student_profile.html', user=user)

@app.route('/student/timetable')
def student_timetable():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='student':
        return redirect(url_for('login'))
    courses = [e.course for e in user.enrollments]
    tt = []
    for c in courses:
        for t in c.timetable:
            tt.append({'course': c, 'day': t.day, 'start': t.start_time, 'end': t.end_time, 'loc': t.location})
    return render_template('timetable.html', entries=tt, user=user)

@app.route('/student/grades')
def student_grades():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='student':
        return redirect(url_for('login'))
    grades = Grade.query.filter_by(student_id=user.id).all()
    return render_template('student_grades.html', grades=grades, user=user)

@app.route('/student/attendance')
def student_attendance():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='student':
        return redirect(url_for('login'))
    att = Attendance.query.filter_by(student_id=user.id).order_by(Attendance.date.desc()).all()
    return render_template('student_attendance.html', attendance=att, user=user)

# --- Faculty views ---
@app.route('/faculty/dashboard')
def faculty_dashboard():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='faculty':
        return redirect(url_for('login'))
    courses = user.courses
    # students in faculty courses
    course_students = {c.id: [en.student for en in c.enrollments] for c in courses}
    return render_template('faculty_dashboard.html', user=user, courses=courses, course_students=course_students)

@app.route('/faculty/profile')
def faculty_profile():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='faculty':
        return redirect(url_for('login'))
    return render_template('faculty_profile.html', user=user)

@app.route('/faculty/course/<int:course_id>')
def faculty_course(course_id):
    user = User.query.get(session.get('user_id'))
    c = Course.query.get(course_id)
    if not user or user.role!='faculty' or c.faculty_id!=user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('faculty_dashboard'))
    students = [en.student for en in c.enrollments]
    grades = Grade.query.filter_by(course_id=c.id).all()
    return render_template('faculty_course.html', course=c, students=students, grades=grades, user=user)

@app.route('/faculty/attendance/<int:course_id>', methods=['GET','POST'])
def faculty_attendance(course_id):
    user = User.query.get(session.get('user_id'))
    c = Course.query.get(course_id)
    if not user or user.role!='faculty' or c.faculty_id!=user.id:
        return redirect(url_for('faculty_dashboard'))
    if request.method=='POST':
        date_str = request.form['date']
        for key,val in request.form.items():
            if key.startswith('present_'):
                student_id = int(key.split('_',1)[1])
                present = True if val=='on' else False
                # upsert attendance
                from datetime import datetime
                adate = datetime.strptime(date_str, '%Y-%m-%d').date()
                att = Attendance.query.filter_by(course_id=c.id, student_id=student_id, date=adate).first()
                if not att:
                    att = Attendance(course_id=c.id, student_id=student_id, date=adate, present=present)
                    db.session.add(att)
                else:
                    att.present = present
        db.session.commit()
        flash('Attendance updated', 'success')
        return redirect(url_for('faculty_course', course_id=c.id))
    students = [en.student for en in c.enrollments]
    return render_template('faculty_attendance.html', course=c, students=students, user=user)

@app.route('/faculty/grade/<int:course_id>', methods=['GET','POST'])
def faculty_grade(course_id):
    user = User.query.get(session.get('user_id'))
    c = Course.query.get(course_id)
    if not user or user.role!='faculty' or c.faculty_id!=user.id:
        return redirect(url_for('faculty_dashboard'))
    if request.method=='POST':
        for key,val in request.form.items():
            if key.startswith('marks_'):
                student_id = int(key.split('_',1)[1])
                try:
                    marks = float(val)
                except:
                    marks = None
                if marks is not None:
                    # upsert grade
                    g = Grade.query.filter_by(course_id=c.id, student_id=student_id).first()
                    if not g:
                        g = Grade(course_id=c.id, student_id=student_id, marks=marks)
                        db.session.add(g)
                    else:
                        g.marks = marks
                    # compute letter
                    if marks >= 85:
                        g.letter = 'A'
                    elif marks >= 70:
                        g.letter = 'B'
                    elif marks >= 55:
                        g.letter = 'C'
                    else:
                        g.letter = 'D'
        db.session.commit()
        flash('Grades updated', 'success')
        return redirect(url_for('faculty_course', course_id=c.id))
    students = [en.student for en in c.enrollments]
    grades = {g.student_id: g for g in c.grades}
    return render_template('faculty_grade.html', course=c, students=students, grades=grades, user=user)

@app.route('/faculty/timetable')
def faculty_timetable():
    user = User.query.get(session.get('user_id'))
    if not user or user.role!='faculty':
        return redirect(url_for('login'))
    tt = []
    for c in user.courses:
        for t in c.timetable:
            tt.append({'course': c, 'day': t.day, 'start': t.start_time, 'end': t.end_time, 'loc': t.location})
    return render_template('timetable.html', entries=tt, user=user)

# --- Simple registration route for demo to create extra users (not for production) ---
@app.route('/register_demo', methods=['GET','POST'])
def register_demo():
    if request.method=='POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('register_demo'))
        u = User(username=username, password_hash=generate_password_hash(password), role=role, full_name=request.form.get('full_name'))
        db.session.add(u)
        db.session.commit()
        flash('User created', 'success')
        return redirect(url_for('login'))
    return render_template('register_demo.html')

# --- Run ---
if __name__ == '__main__':
    app.run(debug=True)
